import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { parse as parseCookie } from "cookie";
import { SignJWT, jwtVerify } from "jose";
import type { Request, Response } from "express";
import type { User } from "../../drizzle/schema";
import * as db from "../db";

const scrypt = promisify(scryptCallback);
const SESSION_COOKIE = "tablojadoo_session";
const SESSION_DAYS = 30;

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return scrypt(password, salt, 64).then(key => `${salt}:${Buffer.from(key as Buffer).toString("hex")}`);
}

export async function verifyPassword(password: string, stored: string) {
  const [salt, expectedHex] = stored.split(":");
  if (!salt || !expectedHex) return false;
  const actual = Buffer.from((await scrypt(password, salt, 64)) as Buffer);
  const expected = Buffer.from(expectedHex, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function secret() {
  const value = process.env.APP_SESSION_SECRET;
  if (!value || value.length < 32) throw new Error("APP_SESSION_SECRET با حداقل ۳۲ کاراکتر لازم است");
  return new TextEncoder().encode(value);
}

export async function createLocalSession(user: User) {
  return new SignJWT({ userId: user.id, username: user.username, role: user.role })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(secret());
}

export async function readLocalUser(req: Request): Promise<User | null> {
  const cookies = parseCookie(req.headers.cookie ?? "");
  let token = cookies[SESSION_COOKIE];
  const auth = req.headers.authorization;
  if (!token && auth?.startsWith("Bearer ")) token = auth.slice(7);
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret(), { algorithms: ["HS256"] });
    const userId = Number(payload.userId);
    if (!Number.isInteger(userId) || userId < 1) return null;
    return (await db.getUserById(userId)) ?? null;
  } catch {
    return null;
  }
}

export function setSessionCookie(res: Response, token: string) {
  res.cookie(SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: SESSION_DAYS * 24 * 60 * 60 * 1000 });
}

export function clearSessionCookie(res: Response) {
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/" });
}

export { SESSION_COOKIE };
