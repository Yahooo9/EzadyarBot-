import * as db from "../db";

type ChatMessage = { role: string; content: unknown };

export async function askConfiguredAi(ownerId: number, messages: ChatMessage[]) {
  const setting = await db.getAiSetting(ownerId);
  if (!setting?.enabled || !setting.apiKey) throw new Error("اتصال هوش مصنوعی هنوز فعال نشده است");
  const response = await fetch(`${setting.baseUrl}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${setting.apiKey}` },
    body: JSON.stringify({ model: setting.modelName, messages, temperature: 0.35, max_tokens: 700 }),
    signal: AbortSignal.timeout(45_000),
  });
  if (!response.ok) throw new Error(`AI provider returned HTTP ${response.status}`);
  const data = await response.json() as { choices?: Array<{ message?: { content?: string | Array<{ text?: string }> } }> };
  const content = data.choices?.[0]?.message?.content;
  if (Array.isArray(content)) return content.map(item => item.text ?? "").join(" ").trim();
  return typeof content === "string" ? content.trim() : "";
}

export async function getConfiguredAiStatus(ownerId: number) {
  const setting = await db.getAiSetting(ownerId);
  return { configured: Boolean(setting), enabled: Boolean(setting?.enabled), baseUrl: setting?.baseUrl ?? "", modelName: setting?.modelName ?? "" };
}
