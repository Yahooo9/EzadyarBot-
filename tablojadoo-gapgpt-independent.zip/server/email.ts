import nodemailer from "nodemailer";
import * as db from "./db";

export async function sendEmail(ownerId: number, input: { to: string; subject: string; text: string; html?: string }) {
  const setting = await db.getEmailSetting(ownerId);
  if (!setting?.enabled) throw new Error("اتصال SMTP فعال نشده است");
  const transporter = nodemailer.createTransport({ host: setting.host, port: setting.port, secure: setting.secure, auth: { user: setting.username, pass: setting.password } });
  const result = await transporter.sendMail({ from: setting.fromAddress, to: input.to, subject: input.subject, text: input.text, html: input.html });
  return { messageId: result.messageId, accepted: result.accepted };
}
