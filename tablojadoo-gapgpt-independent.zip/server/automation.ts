import { createHmac, timingSafeEqual } from "node:crypto";
import { Router } from "express";
import * as db from "./db";
import { sendEmail } from "./email";

const windows = new Map<string, { started: number; count: number }>();
function authorized(req: { headers: Record<string, string | string[] | undefined> }) {
  const configured = process.env.AUTOMATION_API_TOKEN;
  const supplied = req.headers["x-automation-token"];
  if (!configured || typeof supplied !== "string") return false;
  const a = createHmac("sha256", "automation").update(supplied).digest();
  const b = createHmac("sha256", "automation").update(configured).digest();
  return timingSafeEqual(a, b);
}
function ownerId() {
  const value = Number(process.env.AUTOMATION_OWNER_ID);
  if (!Number.isInteger(value) || value < 1) throw new Error("AUTOMATION_OWNER_ID is not configured");
  return value;
}
export function createAutomationRouter() {
  const router = Router();
  router.use((req, res, next) => {
    if (!authorized(req)) return res.status(401).json({ error: "invalid automation token" });
    const key = req.ip ?? "unknown";
    const now = Date.now();
    const current = windows.get(key);
    if (!current || now - current.started > 60_000) windows.set(key, { started: now, count: 1 });
    else if (current.count++ >= 60) return res.status(429).json({ error: "rate limit exceeded" });
    next();
  });
  router.get("/leads", async (_req, res) => { try { res.json(await db.getLeadsForUser(ownerId())); } catch (error) { res.status(500).json({ error: error instanceof Error ? error.message : "failed" }); } });
  router.post("/email", async (req, res) => { try { const body = req.body as { to?: string; subject?: string; text?: string; html?: string; approved?: boolean }; if (!body.approved) return res.status(400).json({ error: "manager approval is required" }); if (!body.to || !body.subject || !body.text) return res.status(400).json({ error: "to, subject and text are required" }); res.json(await sendEmail(ownerId(), { to: body.to, subject: body.subject, text: body.text, html: body.html })); } catch (error) { res.status(500).json({ error: error instanceof Error ? error.message : "failed" }); } });
  return router;
}
