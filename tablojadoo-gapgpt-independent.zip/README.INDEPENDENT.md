# نسخهٔ مستقل CRM/بازاریابی تابلو جادو با اتصال دستی GapGPT

این پوشه یک کپی مستقل از نسخهٔ اصلی است و تغییرات آن روی `/home/ubuntu/tablojadoo` اعمال نشده است. در این نسخه، ورود، نشست، تنظیمات AI و ایمیل در backend خود پروژه انجام می‌شود و برای اجرای production به Manus نیاز ندارد.

## پیش‌نیازها

- Node.js نسخهٔ 22.x
- pnpm نسخهٔ 10.x (ترجیحاً 10.18.0)
- MySQL یا MariaDB
- HTTPS برای production و webhookهای Telegram/WhatsApp
- برای Gmail: App Password؛ رمز اصلی Gmail را وارد نکنید

## نصب روی VPS یا DirectAdmin دارای Node.js

```bash
unzip tablojadoo-gapgpt-independent.zip
cd tablojadoo-gapgpt
cp .env.example .env
pnpm install --frozen-lockfile
pnpm exec drizzle-kit migrate
pnpm build
pnpm start
```

در DirectAdmin، Node.js App/Passenger را روی Node 22 تنظیم کنید، پوشهٔ اجرای backend را روی همین پروژه بگذارید، متغیرهای `.env` را در محیط برنامه ثبت کنید و فرمان start را `pnpm start` قرار دهید. پورت را از `PORT` محیط هاست بگیرید. اگر هاست فقط `public_html` و PHP دارد، این پروژهٔ کامل Node.js قابل اجرای مستقیم نیست؛ باید VPS، Node.js hosting یا یک backend جداگانه تهیه شود.

## تنظیمات محیطی

فایل `.env.example` فقط نمونه است و هیچ secret واقعی ندارد. این موارد را در `.env` واقعی تکمیل کنید:

- `DATABASE_URL`: رشتهٔ اتصال MySQL/MariaDB.
- `APP_SESSION_SECRET`: با `openssl rand -base64 48` بسازید؛ حداقل ۳۲ کاراکتر.
- `AUTOMATION_API_TOKEN`: با `openssl rand -hex 32` بسازید.
- `AUTOMATION_OWNER_ID`: شناسهٔ عددی مدیر/مالک داده‌هایی که API اتوماسیون به آن دسترسی دارد.
- `GAPGPT_BASE_URL` و `GAPGPT_MODEL`: فقط مقدار پیش‌فرض؛ تنظیم امن اصلی از پنل انجام می‌شود.

فایل `.env` را در ZIP، Git و frontend قرار ندهید.

## ساخت اولین مدیر

بعد از migrate و اجرای برنامه، `/login` را باز کنید. در اولین بار نام کاربری/ایمیل و رمز عبور مدیر را بسازید. پس از ایجاد اولین حساب، ساخت حساب عمومی بسته می‌شود. رمز عبور با `scrypt` ذخیره می‌شود و نشست با JWT محلی و cookie `tablojadoo_session` ایجاد می‌شود.

## اتصال GapGPT

در پنل `/settings` بخش AI را تکمیل کنید:

```text
Base URL: https://api.gapgpt.ir/v1
API Key: کلید واقعی GapGPT، فقط در فرم امن
Model Name: شناسه‌ای که GapGPT رسماً تأیید کرده است
Enabled: فعال
```

برنامه درخواست OpenAI-compatible زیر را ارسال می‌کند:

```text
POST {Base URL}/chat/completions
Authorization: Bearer {API Key}
```

`gpt-6-luna` فقط مقدار پیش‌فرض پروژه است و تا زمان تأیید رسمی GapGPT نباید قطعی تلقی شود. کلید API به browser برگردانده نمی‌شود و در دیتابیس با AES-256-GCM رمزنگاری می‌شود.

## Gmail SMTP

در تنظیمات ایمیل این مقادیر معمولاً مناسب Gmail هستند:

```text
Host: smtp.gmail.com
Port: 587
SSL مستقیم: خاموش (STARTTLS)
Username: آدرس Gmail
App Password: رمز برنامهٔ ۱۶ رقمی
From Address: آدرس مجاز ارسال
Enabled: فعال
```

برای پورت 465 می‌توان SSL مستقیم را فعال کرد. ارسال حساس از مسیر UI و API اتوماسیون فقط با تأیید صریح مدیر (`approved: true`) انجام می‌شود. پیش از ارسال انبوه، محدودیت‌ها و قوانین سرویس ایمیل را بررسی کنید.

## کانال‌های پیامک، Telegram و WhatsApp

تنظیمات کانال‌ها در پنل باقی مانده است و credentialها باید فقط در backend/دیتابیس رمزنگاری‌شده ذخیره شوند:

- پیامک: کلید و sender پنل رسمی پیامکی مانند Kavenegar یا سرویس مجاز خودتان.
- Telegram: Bot Token ساخته‌شده در BotFather؛ webhook فقط روی HTTPS عمومی ثبت شود.
- WhatsApp: WhatsApp Business Cloud API، Phone Number ID، Business Account و access token رسمی؛ از APIهای غیرمجاز یا شبیه‌ساز استفاده نکنید.

این ZIP ادعا نمی‌کند کانالی بدون وارد کردن کلید واقعی فعال است. webhookهای ورودی Telegram/WhatsApp نیازمند آدرس HTTPS، verify token، ثبت webhook در provider و پیاده‌سازی/اتصال handler مناسب در deployment شما هستند. اطلاعات مشتری یا شمارهٔ ساختگی تولید نمی‌شود.

## API امن اتوماسیون

مسیر پایه:

```text
/api/automation
```

تمام درخواست‌ها به header زیر نیاز دارند:

```text
X-Automation-Token: مقدار AUTOMATION_API_TOKEN
```

API مالک داده را از `AUTOMATION_OWNER_ID` می‌گیرد و برای هر IP حدود ۶۰ درخواست در دقیقه اجازه می‌دهد.

### خواندن لیدها

```bash
curl -sS https://YOUR-DOMAIN.example/api/automation/leads \
  -H 'X-Automation-Token: REPLACE_WITH_REAL_TOKEN'
```

### ارسال ایمیل پس از تأیید مدیر

```bash
curl -sS -X POST https://YOUR-DOMAIN.example/api/automation/email \
  -H 'Content-Type: application/json' \
  -H 'X-Automation-Token: REPLACE_WITH_REAL_TOKEN' \
  --data '{"to":"customer@example.com","subject":"پیام شما","text":"متن پیام","approved":true}'
```

بدون `approved: true` ارسال رد می‌شود. توکن را در n8n یا اسکریپت‌ها به‌صورت secret نگه دارید و در URL، log یا frontend ننویسید. برای انتشار عمومی، HTTPS، reverse proxy، محدودیت IP و rate limit سطح وب‌سرور نیز فعال کنید.

## Migration و بروزرسانی

پس از ساخت دیتابیس:

```bash
pnpm exec drizzle-kit migrate
```

Migration مستقل در `drizzle/0005_independent_settings.sql` قرار دارد و جداول حساب مدیر، تنظیمات GapGPT و تنظیمات SMTP را اضافه می‌کند. قبل از migration production از دیتابیس backup بگیرید.

## Build و تست

```bash
pnpm check
pnpm test
pnpm build
```

هشدار chunk بزرگ frontend ممکن است در build دیده شود و مانع build نیست. تست‌ها نباید به Manus یا credential واقعی نیاز داشته باشند.

## استقلال از Manus

routeهای OAuth/Manus از نقطهٔ شروع Express حذف شده‌اند؛ frontend نیز config و login/session مخصوص Manus را load نمی‌کند. چند helper قدیمی برای حفظ ساختار کپی در سورس باقی مانده‌اند و route عملیاتی پروژه آن‌ها را mount یا استفاده نمی‌کند؛ این فایل‌ها نباید با کلید Manus در محیط production فعال شوند. Map نیز در صورت نیاز فقط از `VITE_GOOGLE_MAPS_API_KEY` مرورگریِ محدودشده استفاده می‌کند و proxy Manus ندارد.

## تفاوت نسخهٔ اصلی و این کپی

- نسخهٔ اصلی: `/home/ubuntu/tablojadoo`؛ دست‌نخورده باقی می‌ماند.
- نسخهٔ مستقل: همین پروژه؛ احراز هویت محلی، تنظیم AI دستی، SMTP و API اتوماسیون دارد.
- ظاهر RTL، تم و ساختار CRM نسخهٔ اصلی تا حد امکان حفظ شده است.
- فعال شدن واقعی GapGPT، SMTP، SMS، Telegram و WhatsApp به credential و تنظیمات قانونی شما وابسته است و از داخل ZIP قابل ادعا نیست.
