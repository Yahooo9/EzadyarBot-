import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { APP_NAME } from "@shared/const";
import { toast } from "sonner";

export default function Login() {
  const [, navigate] = useLocation();
  const status = trpc.auth.status.useQuery();
  const [setup, setSetup] = useState({ username: "admin", name: "مدیر", email: "", password: "", confirm: "" });
  const [login, setLogin] = useState({ username: "", password: "" });
  const loginMutation = trpc.auth.login.useMutation({ onSuccess: () => { toast.success("ورود موفق بود"); navigate("/"); }, onError: e => toast.error(e.message) });
  const setupMutation = trpc.auth.setup.useMutation({ onSuccess: () => { toast.success("حساب مدیر ساخته شد"); navigate("/"); }, onError: e => toast.error(e.message) });
  const needsSetup = status.data?.needsSetup;
  const submit = (event: React.FormEvent) => { event.preventDefault(); if (needsSetup) { if (setup.password !== setup.confirm) return toast.error("تکرار رمز یکسان نیست"); setupMutation.mutate({ username: setup.username, name: setup.name, email: setup.email, password: setup.password }); } else loginMutation.mutate(login); };
  return <div dir="rtl" className="flex min-h-screen items-center justify-center bg-[#08070d] px-4 text-white"><div className="w-full max-w-md rounded-3xl border border-[#8d55ff]/25 bg-[#15111f] p-6 shadow-2xl shadow-[#8d55ff]/10 sm:p-8"><div className="mb-7 text-center"><div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#e8bf55] to-[#8d55ff] text-xl font-black">م</div><h1 className="text-xl font-black">{APP_NAME}</h1><p className="mt-2 text-xs text-[#a79cad]">ورود امن مستقل از Manus</p></div><form onSubmit={submit} className="space-y-3">{needsSetup ? <><h2 className="mb-4 text-sm font-black text-[#e8bf55]">ساخت حساب مدیر</h2><Input required minLength={3} value={setup.username} onChange={e => setSetup({ ...setup, username: e.target.value })} placeholder="نام کاربری" /><Input required value={setup.name} onChange={e => setSetup({ ...setup, name: e.target.value })} placeholder="نام مدیر" /><Input required type="email" value={setup.email} onChange={e => setSetup({ ...setup, email: e.target.value })} placeholder="ایمیل مدیر" /><Input required minLength={10} type="password" value={setup.password} onChange={e => setSetup({ ...setup, password: e.target.value })} placeholder="رمز عبور حداقل ۱۰ کاراکتر" /><Input required minLength={10} type="password" value={setup.confirm} onChange={e => setSetup({ ...setup, confirm: e.target.value })} placeholder="تکرار رمز عبور" /><Button disabled={setupMutation.isPending} className="gold-button mt-3 w-full">ساخت حساب و ورود</Button></> : <><h2 className="mb-4 text-sm font-black text-[#e8bf55]">ورود مدیر</h2><Input required value={login.username} onChange={e => setLogin({ ...login, username: e.target.value })} placeholder="نام کاربری" /><Input required type="password" value={login.password} onChange={e => setLogin({ ...login, password: e.target.value })} placeholder="رمز عبور" /><Button disabled={loginMutation.isPending} className="gold-button mt-3 w-full">ورود به داشبورد</Button></>}</form><p className="mt-6 text-center text-[10px] leading-6 text-[#786e82]">کلیدهای GapGPT و SMTP فقط در backend رمزنگاری می‌شوند و در مرورگر ذخیره نمی‌شوند.</p></div></div>;
}
