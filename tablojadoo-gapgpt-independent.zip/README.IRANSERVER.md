# دفترچهٔ نصب `(Mooooobadel*&_-__----💰)` روی ایران‌سرور

این راهنما برای ZIP نهایی `tablojadoo-host-final-e512f9a.zip` نوشته شده است. نسخهٔ کامل برنامه یک وب‌اپ Node.js/Express/tRPC با دیتابیس MySQL است؛ بنابراین فقط کپی‌کردن چند فایل داخل `public_html` کافی نیست. برای login، CRM، گزارش‌ها، دستیار فروش، اتصال امن کانال‌ها و API باید Node.js و MySQL در دسترس باشند.

## بخش اول: انتخاب نوع سرویس ایران‌سرور

پیش از آپلود، از پشتیبانی ایران‌سرور بپرسید سرویس شما کدام‌یک از این حالت‌هاست:

1. **VPS لینوکس با SSH و Docker:** بهترین گزینه برای اجرای هم‌زمان پنل و n8n.
2. **هاست Node.js با DirectAdmin و ترمینال:** مناسب اجرای خود پنل، به شرط پشتیبانی از Node.js 22 و اجرای process دائمی.
3. **هاست فقط PHP یا فقط `public_html`:** برای نسخهٔ کامل مناسب نیست؛ backend Node.js، migration و webhookها اجرا نمی‌شوند. در این حالت VPS لینوکس یا هاست Node.js تهیه کنید.

راهنمای ایران‌سرور ورود به DirectAdmin را معمولاً با `https://DOMAIN:2222` یا `https://SERVER-IP:2222` توضیح می‌دهد؛ اطلاعات ورود و IP معمولاً در ایمیل فعال‌سازی سرویس است.[1]

## بخش دوم: آماده‌کردن اطلاعات

قبل از شروع این موارد را در یک فایل خصوصی یادداشت کنید:

```text
دامنه: example.ir
IP عمومی VPS یا IP هاست: 203.0.113.10
نام کاربری DirectAdmin: از ایمیل ایران‌سرور
نام دیتابیس: از DirectAdmin
نام کاربر دیتابیس: از DirectAdmin
رمز دیتابیس: رمز ساخته‌شده توسط شما
```

برای این پروژه به Node.js **22.x**، pnpm **10.18.0** و MySQL 8 یا MariaDB سازگار با `mysql2` نیاز دارید. رمزهای زیر را هرگز در GitHub، چت یا فایل ZIP عمومی قرار ندهید:

```text
DATABASE_URL
MANUS_JWT_SECRET
MANUS_API_KEY
Telegram Bot Token
WhatsApp Access Token
Kavenegar API Key
```

## بخش سوم: اتصال دامنه و DNS

ابتدا مشخص کنید DNS دامنه کجا مدیریت می‌شود. اگر Name Serverهای دامنه روی ایران‌سرور هستند، DNS را در پنل ایران‌سرور/مدیریت DNS همان‌جا تغییر دهید. اگر روی Cloudflare یا شرکت دیگری هستند، رکورد را همان‌جا تغییر دهید؛ ثبت رکورد در پنل اشتباه اثر ندارد.

ایران‌سرور برای اتصال دامنه به VPS روش رکورد A را برای بیشتر کاربران پیشنهاد می‌کند. برای دامنهٔ اصلی، IP عمومی VPS را قرار دهید و برای `www` معمولاً CNAME به دامنهٔ اصلی بسازید.[2]

نمونهٔ رکوردها؛ مقدار IP را با IP واقعی خودتان عوض کنید:

```text
Type   Name   Value / Target       TTL
A      @      IP_PUBLIC_VPS        300
CNAME  www    example.ir           300
A      n8n    IP_PUBLIC_VPS        300   # فقط اگر n8n نصب می‌کنید
```

همهٔ رکوردهای قبلی را حذف نکنید. رکوردهای `MX`، `TXT`، `CNAME` و `AAAA` ممکن است برای ایمیل یا سرویس‌های دیگر باشند. تغییر DNS معمولاً فوری نیست و ممکن است تا ۱ تا ۲۴ ساعت زمان ببرد.[2]

تست از کامپیوتر یا VPS:

```bash
nslookup example.ir
nslookup www.example.ir
nslookup n8n.example.ir
```

برای VPS لینوکس، پورت‌های ۸۰ و ۴۴۳ باید باز باشند. پورت ۲۲ فقط برای SSH لازم است و پورت ۳۰۰۰/۵۶۷۸ را عمومی نکنید؛ این پورت‌ها باید پشت Nginx بمانند.

## مسیر A: نصب روی VPS ایران‌سرور با Docker

این مسیر برای اجرای هم‌زمان پنل و n8n توصیه می‌شود.

### ۱. ورود و نصب پیش‌نیازها

```bash
ssh root@IP_PUBLIC_VPS
apt-get update
apt-get install -y curl unzip nginx certbot python3-certbot-nginx
```

Docker را نصب کنید:

```bash
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker

docker --version
docker compose version
```

### ۲. آپلود و Extract کردن ZIP

ZIP را در `/opt` آپلود کنید. اگر از کامپیوتر خودتان استفاده می‌کنید:

```bash
scp tablojadoo-host-final-e512f9a.zip root@IP_PUBLIC_VPS:/opt/
```

سپس روی VPS:

```bash
mkdir -p /opt/tablojadoo
unzip -q /opt/tablojadoo-host-final-e512f9a.zip -d /opt/tablojadoo
cd /opt/tablojadoo
```

اگر ZIP یک پوشهٔ اضافه ساخت، وارد پوشه‌ای شوید که `package.json` و `docker-compose.production.yml` در آن دیده می‌شوند.

### ۳. ساخت `.env`

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

حداقل مقادیر Docker و برنامه:

```dotenv
NODE_ENV=production
PORT=3000
APP_PORT=3000

MYSQL_DATABASE=tablojadoo
MYSQL_USER=tablojadoo
MYSQL_PASSWORD=یک_رمز_قوی_و_منحصر_به_فرد
MYSQL_ROOT_PASSWORD=یک_رمز_قوی_دیگر

MANUS_PROJECT_ID=شناسه_پروژه
MANUS_JWT_SECRET=یک_رشته_تصادفی_طولانی
MANUS_OAUTH_API_URL=https://api.manus.ai
MANUS_OAUTH_PORTAL_URL=https://manus.im
MANUS_API_URL=https://forge.manus.ai
MANUS_API_KEY=کلید_Manus_درصورت_استفاده
COOKIE_DOMAIN=
```

برای ساخت secret:

```bash
openssl rand -base64 48
```

### ۴. اجرای پنل و migration

```bash
sudo bash scripts/vps-install.sh

docker compose --env-file .env -f docker-compose.production.yml ps
curl http://127.0.0.1:3000/api/health
```

باید پاسخ زیر را ببینید:

```json
{"status":"ok"}
```

Compose دیتابیس MySQL را با volume دائمی اجرا می‌کند و قبل از شروع backend، migrationهای Drizzle را اجرا می‌کند.

### ۵. فعال‌کردن Nginx و SSL

فایل Nginx را کپی و دامنه را عوض کنید:

```bash
cp deploy/nginx-tablojadoo.conf /etc/nginx/sites-available/tablojadoo.conf
sed -i 's/tablojadoo.ir/example.ir/g' /etc/nginx/sites-available/tablojadoo.conf
ln -s /etc/nginx/sites-available/tablojadoo.conf /etc/nginx/sites-enabled/tablojadoo.conf
nginx -t
systemctl reload nginx
```

بعد از اینکه DNS به سرور رسید، SSL بگیرید:

```bash
certbot --nginx -d example.ir -d www.example.ir
```

ایران‌سرور برای DirectAdmin فعال‌کردن `Secure SSL` و سپس `SSL Certificates`/Let’s Encrypt را توضیح داده است؛ در VPS، Certbot و Nginx همین نقش را انجام می‌دهند.[3]

سپس در Chrome اندروید باز کنید:

```text
https://example.ir
https://example.ir/api/health
```

## مسیر B: نصب روی هاست Node.js با DirectAdmin

### ۱. ورود به DirectAdmin

به آدرس زیر بروید:

```text
https://DOMAIN:2222
```

یا از لینک ایمیل فعال‌سازی ایران‌سرور وارد شوید. از بخش **MySQL Management** این موارد را بسازید:

```text
Database
Database User
Strong Password
Full privileges
```

فرمت `DATABASE_URL`:

```dotenv
DATABASE_URL=mysql://DB_USER:DB_PASSWORD@127.0.0.1:3306/DB_NAME
```

اگر رمز دیتابیس دارای `@`، `#`، `/` یا `:` است، آن را URL-encode کنید.

### ۲. آپلود ZIP

در File Manager یک مسیر خارج از `public_html` بسازید؛ مثلاً:

```text
/domains/example.ir/nodeapp
```

ZIP را همان‌جا upload و Extract کنید. در root باید این فایل‌ها و پوشه‌ها دیده شوند:

```text
package.json
pnpm-lock.yaml
client/
server/
drizzle/
shared/
dist/
Dockerfile
.env.example
```

فایل `.env` واقعی را داخل ZIP نگذارید. آن را روی هاست بسازید:

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

### ۳. نصب و migration

در Terminal DirectAdmin:

```bash
cd ~/domains/example.ir/nodeapp
node --version
corepack enable
corepack prepare pnpm@10.18.0 --activate
pnpm --version
pnpm install --frozen-lockfile
pnpm exec drizzle-kit migrate
pnpm check
pnpm build
```

### ۴. ساخت Node.js Application

در **Node.js Selector / Node.js Application / Application Manager**:

```text
Application root: domains/example.ir/nodeapp
Startup file: dist/index.js
Node.js version: 22.x
Application mode: production
Application URL: https://example.ir
```

اگر پنل `.env` را load نمی‌کند، همان environment variables را در تنظیمات Node Application وارد کنید. برنامه روی `process.env.PORT` گوش می‌دهد؛ port داخلی را عمومی نکنید.

### ۵. فعال‌کردن SSL

در DirectAdmin وارد **Domain Setup** شوید، دامنه را انتخاب کنید، `Secure SSL` را فعال کنید و سپس از **SSL Certificates** گواهی Let’s Encrypt را صادر و Save کنید. این مراحل مطابق راهنمای ایران‌سرور برای DirectAdmin است.[3]

## بخش چهارم: تنظیم کانال‌ها از داخل داشبورد

بعد از بازشدن سایت و login:

```text
https://example.ir/settings
```

در بخش «اتصال کانال‌های پیام‌رسان» برای هر کانال credential را وارد کنید، گزینهٔ «فعال» را روشن کنید، **ذخیره** و سپس **تست** را بزنید.

### پیامک ایرانی Kavenegar

در کارت پیامک این فیلدها را وارد کنید:

```text
API Key پنل: API Key کاوه‌نگار
شماره فرستنده: sender یا شمارهٔ خط خدماتی
شماره تست: شماره‌ای که اجازهٔ دریافت تست دارد
متن تست: پیام کوتاه آزمایشی
```

تست Kavenegar در این نسخه یک پیامک واقعی ارسال می‌کند و ممکن است هزینه داشته باشد. API Key فقط در backend رمزنگاری می‌شود و نباید در frontend یا n8n workflow متن‌خام قرار گیرد.

در نسخهٔ فعلی اتصال SMS برای **ارسال و تست مستقیم از تنظیمات** آماده است؛ وبهوک وضعیت تحویل SMS یا پاسخ دریافتی پنل هنوز به‌صورت عمومی در API برنامه پیاده‌سازی نشده است. برای آن باید callback پنل SMS به یک endpoint اختصاصی و امضاشده اضافه شود.

### Telegram

1. در Telegram به `@BotFather` بروید.
2. `/newbot` را اجرا کنید.
3. Bot Token را در کارت تلگرام وارد کنید.
4. برای گرفتن Chat ID، ابتدا به بات پیام بدهید و این URL را باز کنید:

```text
https://api.telegram.org/botYOUR_TOKEN/getUpdates
```

5. مقدار `chat.id` را در `Chat ID` وارد کنید.
6. Save و Test را بزنید.

تست فعلی با `getMe` توکن را بررسی می‌کند و با وجود Chat ID یک پیام واقعی می‌فرستد. Telegram بین `getUpdates` و webhook به‌صورت هم‌زمان یکی را می‌پذیرد؛ اگر webhook فعال کنید، دریافت پیام با `getUpdates` متوقف می‌شود.[4]

### WhatsApp Cloud API

1. در Meta Developers یک App بسازید.
2. محصول WhatsApp را اضافه کنید.
3. در **WhatsApp → API Setup** یک Access Token بگیرید.
4. مقدار **Phone Number ID** را بردارید؛ این با شمارهٔ موبایل یکسان نیست.
5. در کارت واتساپ وارد کنید:

```text
Access Token
Phone Number ID
Graph API Version: نسخهٔ فعال حساب Meta، مثلاً v20.0
```

6. Save و Test را بزنید.

تست فعلی با Graph API اعتبار Access Token و Phone Number ID را بررسی می‌کند و پیام ارسال نمی‌کند. برای دریافت پیام ورودی و status، Meta webhook، verify token، App Secret و endpoint عمومی HTTPS لازم است. خارج از پنجرهٔ خدمات مشتری معمولاً Template تأییدشدهٔ Meta لازم است.[5]

## بخش پنجم: وضعیت webhookهای Telegram و WhatsApp در ZIP

فایل زیر داخل ZIP وجود دارد:

```text
docs/webhook-crm-node-example.ts
```

این فایل نمونهٔ امن برای HMAC، Secret Token، verify واتساپ، جلوگیری اولیه از replay و ثبت لید/activity در CRM است؛ اما در نسخهٔ ZIP فعلی به‌صورت خودکار در backend ثبت نشده است. بنابراین فقط با آپلود ZIP، webhook ورودی فعال نمی‌شود.

اگر می‌خواهید webhook ورودی را فعال کنید:

1. فایل نمونه را با بازبینی فنی به `server/webhooks.ts` منتقل کنید.
2. import مسیرهای آن را از `../server/db` به `./db` اصلاح کنید.
3. در `server/_core/index.ts`، route را قبل از `express.json()` ثبت کنید:

```ts
import { createMessagingWebhookRouter } from "../webhooks";
app.use("/api/webhooks", createMessagingWebhookRouter());
app.use(express.json({ limit: "50mb" }));
```

4. این environment variables را روی سرور تنظیم کنید:

```dotenv
WEBHOOK_OWNER_ID=1
TELEGRAM_WEBHOOK_SECRET=یک_رشته_تصادفی
WHATSAPP_VERIFY_TOKEN=یک_رشته_تصادفی
META_APP_SECRET=App_Secret_متا
```

5. پس از build و restart، برای Telegram webhook را با Secret Token ثبت کنید:

```bash
curl -X POST "https://api.telegram.org/botYOUR_TOKEN/setWebhook" \
  -H 'Content-Type: application/json' \
  -d '{"url":"https://example.ir/api/webhooks/telegram","secret_token":"YOUR_TELEGRAM_WEBHOOK_SECRET","allowed_updates":["message"]}'
```

6. در Meta Developers، callback را روی این آدرس بگذارید:

```text
https://example.ir/api/webhooks/whatsapp
```

7. Verify Token دقیقاً برابر `WHATSAPP_VERIFY_TOKEN` باشد و App Secret برای بررسی `x-hub-signature-256` در backend قرار گیرد.

برای production باید `Set` حافظه‌ای داخل نمونه با جدول دیتابیس دارای unique key روی `(channel, externalId)` جایگزین شود؛ در غیر این صورت بعد از restart احتمال ثبت دوبارهٔ پیام وجود دارد. همچنین اگر چند workspace دارید، یک `WEBHOOK_OWNER_ID` ثابت کافی نیست و باید bot/account به owner درست map شود.

## بخش ششم: نصب n8n روی همان VPS

اگر VPS دارید و می‌خواهید n8n نیز اجرا شود:

```bash
cd /opt/tablojadoo
sudo N8N_DOMAIN=n8n.example.ir bash scripts/install-n8n.sh
```

سپس:

```bash
cp deploy/nginx-n8n.conf /etc/nginx/sites-available/n8n.conf
sed -i 's/n8n.example.com/n8n.example.ir/g' /etc/nginx/sites-available/n8n.conf
ln -s /etc/nginx/sites-available/n8n.conf /etc/nginx/sites-enabled/n8n.conf
nginx -t && systemctl reload nginx
certbot --nginx -d n8n.example.ir
```

بعد از بازکردن `https://n8n.example.ir`، حساب owner را بسازید. کلید `N8N_ENCRYPTION_KEY` را تغییر ندهید؛ credentialهای n8n با آن رمزنگاری می‌شوند. workflow پیشنهادی Telegram + WhatsApp + Claude در فایل زیر است:

```text
docs/n8n-telegram-whatsapp-claude-workflow.md
```

## بخش هفتم: تست نهایی در Chrome اندروید

این تست‌ها را به‌ترتیب انجام دهید:

```bash
curl -I https://example.ir/
curl -i https://example.ir/api/health
```

در Chrome اندروید:

1. `https://example.ir` را باز کنید.
2. login را کامل کنید.
3. به `/settings` بروید.
4. وضعیت Database و Authentication را بررسی کنید.
5. هر کانال را جداگانه ذخیره و تست کنید.
6. برای پیامک، آمادهٔ دریافت هزینهٔ پیام آزمایشی باشید.
7. برای Telegram پیام Test را در Chat مقصد بررسی کنید.
8. برای WhatsApp ابتدا test token و test number متا را بررسی کنید.

اگر سایت باز نشد:

```bash
nslookup example.ir
curl -vk https://example.ir/api/health
sudo systemctl status nginx
sudo docker compose --env-file .env -f docker-compose.production.yml ps
sudo docker compose --env-file .env -f docker-compose.production.yml logs --tail=100 app
```

اگر DNS درست است ولی صفحهٔ پیش‌فرض می‌آید، server block دامنه در Nginx/DirectAdmin تنظیم نشده است. اگر 502 می‌گیرید، backend روی port درست اجرا نیست. اگر login برنمی‌گردد، HTTPS، callback OAuth و `MANUS_JWT_SECRET` را بررسی کنید.

## بخش هشتم: backup و به‌روزرسانی

روی VPS Docker:

```bash
sudo bash scripts/backup-db.sh
sudo bash scripts/vps-update.sh
```

قبل از update از `.env` و volumeهای دیتابیس backup داشته باشید. هیچ‌گاه `docker compose down -v` را روی production اجرا نکنید؛ این دستور volume دیتابیس را حذف می‌کند.

## جمع‌بندی وضعیت نسخه

```text
CRM و داشبورد: فعال
ذخیرهٔ دیتابیس: فعال پس از migration
Kavenegar SMS: اتصال و تست مستقیم از /settings فعال
Telegram: تست token و ارسال تست از /settings فعال
WhatsApp: تست credential و Phone Number ID از /settings فعال
Telegram/WhatsApp inbound webhook: نمونهٔ کد موجود، نیازمند ادغام و deploy جداگانه
n8n: اسکریپت نصب VPS موجود، نیازمند اجرای کاربر روی VPS
```

هیچ دامنه‌ای از داخل این ZIP به‌صورت خودکار به اینترنت ایران متصل نمی‌شود. برای بازشدن در Chrome اندروید، DNS دامنه، سرویس هاست/VPS، Nginx و SSL باید در ایران‌سرور به‌درستی تنظیم شوند. وضعیت دسترسی شبکه به دامنه به DNS و مسیر اینترنت اپراتور نیز وابسته است.

## منابع

[1]: https://blog.iranserver.com/login-to-directadmin/ "راهنمای ورود به DirectAdmin ایران‌سرور"
[2]: https://blog.iranserver.com/connecting-a-domain-to-a-vs/ "راهنمای اتصال دامنه به VPS ایران‌سرور"
[3]: https://blog.iranserver.com/free-ssl/ "راهنمای SSL رایگان و Let’s Encrypt در DirectAdmin"
[4]: https://core.telegram.org/bots/api "Telegram Bot API رسمی"
[5]: https://developers.facebook.com/documentation/business-messaging/whatsapp/get-started "راهنمای رسمی WhatsApp Cloud API متا"
